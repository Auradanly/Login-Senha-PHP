<?php
if(isset($_POST['login']) && isset($_POST['senha'])) {
    if($_POST['login'] === 'user' && $_POST['senha'] === '123456') {
        header("Location: sucesso.html");
        exit;
    } else {
        header("Location: erro.html");
        exit;
    }
} else {
    header("Location: erro.html");
    exit;
}
?>
